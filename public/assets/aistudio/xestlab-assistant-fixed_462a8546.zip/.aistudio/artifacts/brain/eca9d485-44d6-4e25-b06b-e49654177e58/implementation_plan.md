# Xestlab Assistant - Native Android Voice Reminder Architecture

A native Android application written in Kotlin and Jetpack Compose that operates entirely offline. It uses AlarmManager for exact 07:30 daily alarms, launches a foreground TextToSpeech service to vocalize outreach targets, shows rich actionable notifications, and persists state via Preferences DataStore.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions and safeguards are incorporated into the architecture:

- **Data Persistence**: Preferences DataStore with Kotlin `Flow` reactive streams for lightweight, non-blocking local storage.
- **Permissions Flow (Safeguard 1)**: Integrated runtime permission handler in `MainActivity`. If Android 13+ (API 33+), requests `POST_NOTIFICATIONS`. If Android 12+ (API 31+), verifies exact alarm capability and opens `ACTION_REQUEST_SCHEDULE_EXACT_ALARM` if denied. Dashboard includes a dedicated "Grant Missing Permissions" button if any permission is missing.
- **Battery Optimization Whitelist (Safeguard 2)**: Dashboard includes an "Exclude from Battery Saver" button launching `Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` (with fallback to `ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS`) to guarantee reliable alarms on aggressive OEM skins like MIUI/HyperOS (Redmi Note 13).
- **TTS Lifecycle & Notification Auto-Dismiss (Safeguard 3)**: `VoiceReminderService` attaches an `UtteranceProgressListener` to the Android `TextToSpeech` engine. Upon `onDone()` or `onError()`, the service immediately calls `stopForeground(STOP_FOREGROUND_REMOVE)`, cancels the notification, and calls `stopSelf()` so no stuck notification remains after speech concludes.
- **Zero Internet Permissions**: `android.permission.INTERNET` is strictly omitted to preserve privacy and offline security.

---

### 1. Overview & Core Concept

- **What It Does**: Automates a morning vocal accountability routine for studio operators. At 7:30 AM every day, the app executes an exact background alarm, triggers a foreground TextToSpeech service speaking: *"Good morning. Your target today is 10 outreach messages. You have 2 follow-ups due."*, and presents a notification with `Done` and `Snooze` (15m) controls.
- **Target Persona**: Studio founders and freelancers on Android devices (such as Xiaomi/Redmi) who need vocal nudges without cloud dependencies or battery-killer background loops.
- **Key Value**: 100% offline reliability with exact background alarms, clean automatic audio cleanup, and OEM battery whitelist integration.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. *Dashboard View*: Displays current alarm status ("Daily at 07:30 AM"), editable target counters (Outreach Messages: 10, Follow-ups Due: 2), and quick-action buttons.
  2. *Permissions Status Card*: If `POST_NOTIFICATIONS` or `SCHEDULE_EXACT_ALARM` is not granted, a clear prompt and "Grant Permissions" button appears.
  3. *Battery Optimization Whitelist Card*: Dedicated "Disable Battery Optimization" button directing to system settings with instructions for Redmi/Xiaomi background autostart.
  4. *Instant Test Action*: "Test Voice & Notification Now" triggers the foreground TTS service immediately so the user can verify audio playback with screen locked.
  5. *Notification & Spoken Prompt*: When 07:30 AM arrives, the phone speaks the morning message aloud and displays the notification with `Done` and `Snooze`. Once spoken, the notification automatically dismisses.
- **Visual Identity & Theme**:
  - *Aesthetic*: Calm, restrained utilitarian design tailored for productivity.
  - *Color Palette*: Deep teal accent (`#0F5F5C`), light background (`#F7F7F5`), dark background (`#141413`), clean borders, and crisp typography.
  - *Typography*: Android system sans-serif with bold numerical badges and structured card grouping.
  - *Button & Card Radius*: 8px standard corner radius throughout (strictly no pill shapes).

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Preferences DataStore vs. Room Database**
  - *Chosen Approach*: Jetpack Preferences DataStore (`androidx.datastore:datastore-preferences`).
  - *Why*: The app tracks key-value targets, reminder time, and last completion timestamps. DataStore provides asynchronous, thread-safe Kotlin Coroutines/Flow read-writes with zero SQLite boilerplate.
- **Decision 2: Foreground Service Lifecycle Management**
  - *Chosen Approach*: Foreground Service with `UtteranceProgressListener`.
  - *Why*: Running as a foreground service with `specialUse` prevents Android 12-15 from killing the process while TTS initializes. Once speech completes, `stopSelf()` is called inside `onDone()` to ensure the service and notification tear down cleanly.
- **Decision 3: Exact Alarm via AlarmManager**
  - *Chosen Approach*: `AlarmManager.setExactAndAllowWhileIdle()` with `RTC_WAKEUP`.
  - *Why*: Guarantees wake-up at 07:30 AM regardless of Doze mode, combined with the battery optimization ignore intent for devices like Redmi Note 13.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────┐
│                       Jetpack Compose UI                        │
│               (MainActivity / Status Dashboard)                 │
│  - Alarm Status Card (07:30 AM)                                 │
│  - Target Counters (10 Outreach, 2 Follow-ups)                  │
│  - Permission Status & "Grant Permissions" Button               │
│  - "Disable Battery Optimization" Button (Redmi/Xiaomi)         │
│  - "Test Voice & Notification Now" Button                       │
└────────────────────────────────┬────────────────────────────────┘
                                 │ Observes Flow / Dispatches
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│               DataStore Repository (Preferences)                │
│       - messageTarget (default: 10)                             │
│       - followUpTarget (default: 2)                             │
│       - alarmHour: 7, alarmMinute: 30                           │
│       - lastCompletedDate                                       │
└────────────────────────────────┬────────────────────────────────┘
                                 │ Schedules / Reads
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                  AlarmManager & Broadcast Receivers             │
│   - Exact Alarm: 07:30 AM daily (AlarmManager)                  │
│   - AlarmReceiver: ACTION_ALARM_FIRE, ACTION_DONE, ACTION_SNOOZE│
│   - BootReceiver: Reschedules after device restart              │
└────────────────────────────────┬────────────────────────────────┘
                                 │ Launches on Trigger
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│             VoiceReminderService (Foreground Service)           │
│   - specialUse Foreground Service with Notification             │
│   - Android TextToSpeech with UtteranceProgressListener         │
│   - Notification Actions: [Done] and [Snooze 15m]               │
│   - onDone / onError -> stopForeground(REMOVE) -> stopSelf()    │
└─────────────────────────────────────────────────────────────────┘
```

- **File Structure to Deliver**:
  - `app/build.gradle.kts`: Configured with SDK 35, Jetpack Compose BOM, DataStore Preferences, Core KTX, Lifecycle ViewModel Compose, and Material 3.
  - `app/src/main/AndroidManifest.xml`: Permissions (`SCHEDULE_EXACT_ALARM`, `USE_EXACT_ALARM`, `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE`, `RECEIVE_BOOT_COMPLETED`, `WAKE_LOCK`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`).
  - `app/src/main/java/com/xestlab/assistant/data/ReminderDataStore.kt`: DataStore implementation with Kotlin Flow for reactive reading and suspend functions for saving.
  - `app/src/main/java/com/xestlab/assistant/service/AlarmScheduler.kt`: Exact alarm scheduling, 15m snooze calculations, and daily 07:30 AM recurrence logic.
  - `app/src/main/java/com/xestlab/assistant/service/VoiceReminderService.kt`: Foreground service with `UtteranceProgressListener` stopping itself and dismissing notification on speech completion.
  - `app/src/main/java/com/xestlab/assistant/service/AlarmReceiver.kt`: BroadcastReceiver routing alarm triggers, "Done" clicks, and "Snooze" clicks.
  - `app/src/main/java/com/xestlab/assistant/service/BootReceiver.kt`: Reschedules the 07:30 AM alarm upon device reboot or package update.
  - `app/src/main/java/com/xestlab/assistant/ui/theme/Color.kt` & `Theme.kt`: Clean teal and neutral theme with 8px corner radius.
  - `app/src/main/java/com/xestlab/assistant/ui/DashboardScreen.kt`: Jetpack Compose UI with status card, target counters, permissions alert, battery optimization intent, and test trigger.
  - `app/src/main/java/com/xestlab/assistant/MainActivity.kt`: Entry activity hosting Compose theme, permissions request launcher, and battery optimization intent.

package com.xestlab.assistant.service

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_ALARM_FIRE = "com.xestlab.assistant.ACTION_ALARM_FIRE"
        const val ACTION_NOTIFICATION_DONE = "com.xestlab.assistant.ACTION_NOTIFICATION_DONE"
        const val ACTION_NOTIFICATION_SNOOZE = "com.xestlab.assistant.ACTION_NOTIFICATION_SNOOZE"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val id = intent.getStringExtra(AlarmScheduler.EXTRA_REMINDER_ID) ?: "generic"
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_REMINDER_TITLE) ?: "Reminder"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        when (action) {
            ACTION_ALARM_FIRE -> {
                val service = Intent(context, ReminderService::class.java).apply {
                    putExtra(ReminderService.EXTRA_REMINDER_ID, id)
                    putExtra(ReminderService.EXTRA_TITLE, title)
                    putExtra(
                        ReminderService.EXTRA_VOICE_ENABLED,
                        intent.getBooleanExtra(AlarmScheduler.EXTRA_VOICE_ENABLED, true)
                    )
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(service)
                } else {
                    context.startService(service)
                }
            }

            ACTION_NOTIFICATION_DONE -> {
                manager.cancel(ReminderService.NOTIFICATION_ID)
                AlarmScheduler.cancelNudges(context)
            }

            ACTION_NOTIFICATION_SNOOZE -> {
                manager.cancel(ReminderService.NOTIFICATION_ID)
                Log.d("AlarmReceiver", "Snoozing $id for 15 minutes")
                AlarmScheduler.scheduleSnooze(context, id, title, 15)
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    AlarmScheduler.scheduleAllActive(context.applicationContext)
                } finally {
                    pending.finish()
                }
            }
        }
    }
}

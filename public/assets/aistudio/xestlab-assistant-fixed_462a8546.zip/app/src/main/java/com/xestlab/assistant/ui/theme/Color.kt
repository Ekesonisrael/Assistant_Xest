package com.xestlab.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val TealAccent = Color(0xFF0F5F5C)
val TealAccentDark = Color(0xFF2BA5A0)

val BgLight = Color(0xFFF7F7F5)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceSubtleLight = Color(0xFFEFEFEA)
val BorderLight = Color(0xFFE0E0DC)
val TextPrimaryLight = Color(0xFF1A1A1A)
val TextMutedLight = Color(0xFF666666)

val BgDark = Color(0xFF141413)
val SurfaceDark = Color(0xFF1E1E1C)
val SurfaceSubtleDark = Color(0xFF272725)
val BorderDark = Color(0xFF333330)
val TextPrimaryDark = Color(0xFFF2F2F0)
val TextMutedDark = Color(0xFF9E9E99)

val WarningRed = Color(0xFFB3261E)
val WarningRedDark = Color(0xFFE05349)

package com.xestlab.assistant.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.xestlab.assistant.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Goal::class,
        ChecklistItem::class,
        DailyLog::class,
        ReminderSchedule::class,
        UserSettings::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun goalDao(): GoalDao
    abstract fun checklistDao(): ChecklistDao
    abstract fun dailyLogDao(): DailyLogDao
    abstract fun reminderDao(): ReminderDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "xestlab_assistant.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            seedDefaultData(getInstance(context))
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDefaultData(db: AppDatabase) {
            // Default Goal
            db.goalDao().saveGoals(
                Goal(
                    id = 1,
                    yearlyGoal = 10000000L,
                    startDate = "2026-11-01",
                    q1Target = 1500000L,
                    q2Target = 2400000L,
                    q3Target = 3200000L,
                    q4Target = 3500000L,
                    weeklyMessagesTarget = 50,
                    weeklyConversationsTarget = 5,
                    weeklyQuotesTarget = 3
                )
            )

            // Default Checklist Items
            val defaultItems = listOf(
                ChecklistItem("messages10", "10 personalised messages sent", isCountType = true, defaultTargetCount = 10, orderIndex = 1),
                ChecklistItem("followups", "Follow-ups due sent", isCountType = false, orderIndex = 2),
                ChecklistItem("content", "One content post", isCountType = false, orderIndex = 3),
                ChecklistItem("study", "One study block", isCountType = false, orderIndex = 4),
                ChecklistItem("leadsheet", "Lead sheet updated", isCountType = false, orderIndex = 5)
            )
            db.checklistDao().insertItems(defaultItems)

            // Default Reminder Schedules
            val defaultReminders = listOf(
                ReminderSchedule("morning", "Morning briefing", "07:30", isRepeating = true, daysOfWeek = "ALL", voiceEnabled = true, isActive = true, isBuiltIn = true),
                ReminderSchedule("midday", "Midday nudge", "12:30", isRepeating = true, daysOfWeek = "ALL", voiceEnabled = true, isActive = true, isBuiltIn = true),
                ReminderSchedule("evening", "Evening check-in", "19:30", isRepeating = true, daysOfWeek = "ALL", voiceEnabled = true, isActive = true, isBuiltIn = true),
                ReminderSchedule("sunday", "Sunday review", "18:00", isRepeating = true, daysOfWeek = "SUN", voiceEnabled = true, isActive = true, isBuiltIn = true)
            )
            db.reminderDao().insertAll(defaultReminders)

            // Default User Settings
            db.settingsDao().saveSettings(
                UserSettings(
                    id = 1,
                    userName = "Studio Lead",
                    quietHoursStart = "22:00",
                    quietHoursEnd = "07:00",
                    quietHoursEnabled = true,
                    voiceSpeed = 1.0f,
                    isFirstRunComplete = false
                )
            )
        }
    }
}

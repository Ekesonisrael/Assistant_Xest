package com.xestlab.assistant.data.local

import androidx.room.*
import com.xestlab.assistant.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE id = 1 LIMIT 1")
    fun getGoals(): Flow<Goal?>

    @Query("SELECT * FROM goals WHERE id = 1 LIMIT 1")
    suspend fun getGoalsDirect(): Goal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGoals(goal: Goal)
}

@Dao
interface ChecklistDao {
    @Query("SELECT * FROM checklist_items ORDER BY orderIndex ASC")
    fun getAllItems(): Flow<List<ChecklistItem>>

    @Query("SELECT * FROM checklist_items ORDER BY orderIndex ASC")
    suspend fun getAllItemsDirect(): List<ChecklistItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<ChecklistItem>)
}

@Dao
interface DailyLogDao {
    @Query("SELECT * FROM daily_logs WHERE date = :date ORDER BY timestamp DESC")
    fun getLogsForDate(date: String): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs WHERE date = :date")
    suspend fun getLogsForDateDirect(date: String): List<DailyLog>

    @Query("SELECT * FROM daily_logs WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getLogsBetweenDates(startDate: String, endDate: String): List<DailyLog>

    @Query("SELECT * FROM daily_logs ORDER BY timestamp DESC")
    suspend fun getAllLogs(): List<DailyLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: DailyLog)

    @Query("DELETE FROM daily_logs WHERE date = :date AND itemId = :itemId")
    suspend fun deleteLogForItem(date: String, itemId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<DailyLog>)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminder_schedules WHERE isActive = 1")
    fun getActiveReminders(): Flow<List<ReminderSchedule>>

    @Query("SELECT * FROM reminder_schedules")
    fun getAllReminders(): Flow<List<ReminderSchedule>>

    @Query("SELECT * FROM reminder_schedules")
    suspend fun getAllRemindersDirect(): List<ReminderSchedule>

    @Query("SELECT * FROM reminder_schedules WHERE id = :id LIMIT 1")
    suspend fun getReminderById(id: String): ReminderSchedule?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderSchedule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reminders: List<ReminderSchedule>)

    @Delete
    suspend fun deleteReminder(reminder: ReminderSchedule)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<UserSettings?>

    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsDirect(): UserSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: UserSettings)
}

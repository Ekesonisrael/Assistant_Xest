package com.xestlab.assistant.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xestlab.assistant.data.model.ReminderSchedule
import com.xestlab.assistant.ui.theme.Shapes8px
import com.xestlab.assistant.ui.theme.TealAccent
import com.xestlab.assistant.ui.theme.WarningRed
import com.xestlab.assistant.ui.viewmodel.AssistantViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: AssistantViewModel,
    onNavigateToSetup: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsState()
    val reminders by viewModel.reminders.collectAsState()

    var nameInput by remember(settings.userName) { mutableStateOf(settings.userName) }
    var quietStart by remember(settings.quietHoursStart) { mutableStateOf(settings.quietHoursStart) }
    var quietEnd by remember(settings.quietHoursEnd) { mutableStateOf(settings.quietHoursEnd) }
    var quietEnabled by remember(settings.quietHoursEnabled) { mutableStateOf(settings.quietHoursEnabled) }
    var voiceSpeed by remember(settings.voiceSpeed) { mutableFloatStateOf(settings.voiceSpeed) }

    var importText by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }
    var showAddReminderDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = Shapes8px,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "User Profile and Greeting",
                        fontSize = 15.dp.value.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Your Name (spoken by assistant)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = Shapes8px.small,
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            viewModel.saveUserSettings(settings.copy(userName = nameInput))
                        },
                        shape = Shapes8px.small,
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                    ) {
                        Text("Save name")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = Shapes8px,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Voice Settings and Quiet Hours",
                        fontSize = 15.dp.value.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Voice Speed: ${String.format("%.1fx", voiceSpeed)}", fontSize = 13.dp.value.sp)
                    Slider(
                        value = voiceSpeed,
                        onValueChange = {
                            voiceSpeed = it
                            viewModel.saveUserSettings(settings.copy(voiceSpeed = it))
                        },
                        valueRange = 0.7f..1.4f,
                        steps = 6,
                        colors = SliderDefaults.colors(thumbColor = TealAccent, activeTrackColor = TealAccent)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Enable Quiet Hours", fontSize = 13.dp.value.sp, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = quietEnabled,
                            onCheckedChange = {
                                quietEnabled = it
                                viewModel.saveUserSettings(settings.copy(quietHoursEnabled = it))
                            }
                        )
                    }

                    if (quietEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = quietStart,
                                onValueChange = { quietStart = it },
                                label = { Text("Start (HH:mm)") },
                                modifier = Modifier.weight(1f),
                                shape = Shapes8px.small,
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = quietEnd,
                                onValueChange = { quietEnd = it },
                                label = { Text("End (HH:mm)") },
                                modifier = Modifier.weight(1f),
                                shape = Shapes8px.small,
                                singleLine = true
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                viewModel.saveUserSettings(
                                    settings.copy(
                                        quietHoursStart = quietStart,
                                        quietHoursEnd = quietEnd
                                    )
                                )
                            },
                            shape = Shapes8px.small,
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                        ) {
                            Text("Save quiet hours")
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = Shapes8px,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Scheduled Reminders",
                            fontSize = 15.dp.value.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Button(
                            onClick = { showAddReminderDialog = true },
                            shape = Shapes8px.small,
                            colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("+ Add")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    reminders.forEach { reminder ->
                        ReminderRow(
                            reminder = reminder,
                            onToggleActive = { viewModel.toggleReminderActive(reminder) },
                            onToggleVoice = { viewModel.toggleReminderVoice(reminder) },
                            onUpdateTime = { newTime -> viewModel.updateReminderTime(reminder, newTime) },
                            onDelete = { viewModel.deleteCustomReminder(reminder) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = Shapes8px,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Backup, Restore and Setup",
                        fontSize = 15.dp.value.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Export and import your logged checks and settings. You can also paste the JSON export from your web goal tracker.",
                        fontSize = 12.dp.value.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val json = viewModel.repository.exportJson()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Xestlab Backup JSON", json))
                                    viewModel.showToast("Backup JSON copied to clipboard")
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = Shapes8px.small,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Text("Export JSON")
                        }

                        Button(
                            onClick = { showImportDialog = true },
                            modifier = Modifier.weight(1f),
                            shape = Shapes8px.small,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Text("Import JSON")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onNavigateToSetup,
                        modifier = Modifier.fillMaxWidth(),
                        shape = Shapes8px.small,
                        colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                    ) {
                        Text("Reopen Setup and Phone Autostart Guide")
                    }
                }
            }
        }
    }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("Import Backup JSON") },
            text = {
                Column {
                    Text("Paste your exported JSON (native backup or web goal tracker):", fontSize = 12.dp.value.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = importText,
                        onValueChange = { importText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        shape = Shapes8px.small,
                        placeholder = { Text("{\n  \"settings\": ...\n}") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val success = viewModel.repository.importJson(importText)
                            if (success) {
                                viewModel.showToast("Data imported successfully")
                                viewModel.refreshWeeklySummary()
                                showImportDialog = false
                            } else {
                                viewModel.showToast("Failed to parse JSON")
                            }
                        }
                    },
                    shape = Shapes8px.small,
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Text("Import")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showImportDialog = false },
                    shape = Shapes8px.small
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showAddReminderDialog) {
        var newTitle by remember { mutableStateOf("") }
        var newTime by remember { mutableStateOf("15:00") }
        var newRepeating by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showAddReminderDialog = false },
            title = { Text("Add Custom Reminder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Title") },
                        shape = Shapes8px.small,
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newTime,
                        onValueChange = { newTime = it },
                        label = { Text("Time (HH:mm)") },
                        shape = Shapes8px.small,
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Repeat daily", fontSize = 13.dp.value.sp)
                        Switch(checked = newRepeating, onCheckedChange = { newRepeating = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTitle.isNotBlank() && newTime.isNotBlank()) {
                            viewModel.addCustomReminder(newTitle, newTime, newRepeating)
                            showAddReminderDialog = false
                        }
                    },
                    shape = Shapes8px.small,
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showAddReminderDialog = false },
                    shape = Shapes8px.small
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ReminderRow(
    reminder: ReminderSchedule,
    onToggleActive: () -> Unit,
    onToggleVoice: () -> Unit,
    onUpdateTime: (String) -> Unit,
    onDelete: () -> Unit
) {
    var editTime by remember(reminder.timeString) { mutableStateOf(reminder.timeString) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primaryContainer, Shapes8px.small)
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = reminder.title,
                fontSize = 13.dp.value.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${reminder.timeString} · ",
                    fontSize = 12.dp.value.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = if (reminder.voiceEnabled) "Voice On" else "Voice Muted",
                    fontSize = 11.dp.value.sp,
                    color = if (reminder.voiceEnabled) TealAccent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(
                onClick = onToggleVoice,
                modifier = Modifier.size(32.dp)
            ) {
                Text(
                    text = if (reminder.voiceEnabled) "SPK" else "MUT",
                    fontSize = 10.dp.value.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (reminder.voiceEnabled) TealAccent else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }

            Switch(
                checked = reminder.isActive,
                onCheckedChange = { onToggleActive() },
                modifier = Modifier.scale(0.8f)
            )

            if (!reminder.isBuiltIn) {
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Text(text = "DEL", fontSize = 9.dp.value.sp, color = WarningRed)
                }
            }
        }
    }
}

private fun Modifier.scale(scale: Float): Modifier = this.then(
    Modifier.padding(0.dp) // placeholder for standard sizing
)

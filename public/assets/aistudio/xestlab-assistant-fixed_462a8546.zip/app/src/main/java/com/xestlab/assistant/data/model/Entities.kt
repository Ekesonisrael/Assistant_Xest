package com.xestlab.assistant.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey val id: Int = 1,
    val yearlyGoal: Long = 10000000L,
    val startDate: String = "2026-11-01",
    val q1Target: Long = 1500000L,
    val q2Target: Long = 2400000L,
    val q3Target: Long = 3200000L,
    val q4Target: Long = 3500000L,
    val weeklyMessagesTarget: Int = 50,
    val weeklyConversationsTarget: Int = 5,
    val weeklyQuotesTarget: Int = 3
)

@Entity(tableName = "checklist_items")
data class ChecklistItem(
    @PrimaryKey val id: String,
    val title: String,
    val isCountType: Boolean = false,
    val defaultTargetCount: Int = 0,
    val orderIndex: Int = 0
)

@Entity(tableName = "daily_logs")
data class DailyLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String, // format: yyyy-MM-dd
    val itemId: String,
    val isDone: Boolean,
    val countValue: Int = 0,
    val reasonNotDone: String? = null, // "busy", "forgot", "avoided it", "other"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminder_schedules")
data class ReminderSchedule(
    @PrimaryKey val id: String,
    val title: String,
    val timeString: String, // HH:mm format, e.g. "07:30"
    val isRepeating: Boolean = true,
    val daysOfWeek: String = "ALL", // "ALL" or comma-separated days e.g. "SUN"
    val voiceEnabled: Boolean = true,
    val isActive: Boolean = true,
    val isBuiltIn: Boolean = true
)

@Entity(tableName = "user_settings")
data class UserSettings(
    @PrimaryKey val id: Int = 1,
    val userName: String = "Studio Lead",
    val quietHoursStart: String = "22:00",
    val quietHoursEnd: String = "07:00",
    val quietHoursEnabled: Boolean = true,
    val voiceSpeed: Float = 1.0f,
    val isFirstRunComplete: Boolean = false
)

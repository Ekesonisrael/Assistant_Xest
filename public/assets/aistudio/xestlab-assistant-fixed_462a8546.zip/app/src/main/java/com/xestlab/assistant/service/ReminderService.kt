package com.xestlab.assistant.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.xestlab.assistant.MainActivity
import com.xestlab.assistant.R
import com.xestlab.assistant.data.local.AppDatabase
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class ReminderService : Service(), TextToSpeech.OnInitListener {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var pendingSpeechText: String? = null
    private var speechSpeed = 1.0f

    companion object {
        const val CHANNEL_ID = "xestlab_reminders_channel"
        const val NOTIFICATION_ID = 1001

        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_VOICE_ENABLED = "extra_voice_enabled"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val reminderId = intent?.getStringExtra(EXTRA_REMINDER_ID) ?: "generic"
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Reminder"
        val voiceEnabled = intent?.getBooleanExtra(EXTRA_VOICE_ENABLED, true) ?: true

        // Display Foreground Notification
        val notification = buildNotification(title, reminderId)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        serviceScope.launch {
            val db = AppDatabase.getInstance(applicationContext)
            val settings = db.settingsDao().getSettingsDirect()
            speechSpeed = settings?.voiceSpeed ?: 1.0f

            val spokenText = if (reminderId == "test") {
                "This is a test reminder from Xestlab Assistant. Exact alarms and voice synthesis are working properly."
            } else {
                VoiceEngine.generateMessage(db, reminderId, title)
            }

            // Update notification with the real text
            val updatedNotification = buildNotification(title, reminderId, spokenText)
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, updatedNotification)

            // Check quiet hours
            val inQuietHours = isCurrentTimeInQuietHours(
                settings?.quietHoursStart ?: "22:00",
                settings?.quietHoursEnd ?: "07:00",
                settings?.quietHoursEnabled ?: true
            )

            // Reschedule next recurrence for built-in reminders
            val reminder = db.reminderDao().getReminderById(reminderId)
            if (reminder != null && reminder.isRepeating) {
                AlarmScheduler.scheduleReminder(applicationContext, reminder)
            }

            // After the evening check-in (and after each nudge), nudge again in 30 minutes
            // only while items are unfinished. The scheduler caps this at 2 per day.
            if (reminderId == "evening" || reminderId == "nudge") {
                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                val doneIds = db.dailyLogDao().getLogsForDateDirect(todayStr)
                    .filter { it.isDone }.map { it.itemId }.toSet()
                val unfinished = db.checklistDao().getAllItemsDirect().count { it.id !in doneIds }
                if (unfinished > 0) {
                    AlarmScheduler.scheduleNudge(applicationContext, 30)
                }
            }

            if (voiceEnabled && !inQuietHours) {
                speakMessage(spokenText)
            } else {
                // If voice suppressed, stop service after brief delay
                delay(3000)
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }

        return START_NOT_STICKY
    }

    private fun isCurrentTimeInQuietHours(start: String, end: String, enabled: Boolean): Boolean {
        if (!enabled) return false
        try {
            val now = Calendar.getInstance()
            val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

            val sParts = start.split(":")
            val startMinutes = sParts[0].toInt() * 60 + sParts[1].toInt()

            val eParts = end.split(":")
            val endMinutes = eParts[0].toInt() * 60 + eParts[1].toInt()

            return if (startMinutes < endMinutes) {
                currentMinutes in startMinutes..endMinutes
            } else {
                currentMinutes >= startMinutes || currentMinutes < endMinutes
            }
        } catch (e: Exception) {
            return false
        }
    }

    private fun speakMessage(text: String) {
        if (isTtsReady && tts != null) {
            tts?.setSpeechRate(speechSpeed)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "xestlab_utterance")
        } else {
            pendingSpeechText = text
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.ENGLISH
            tts?.setSpeechRate(speechSpeed)
            isTtsReady = true

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    serviceScope.launch {
                        delay(1000)
                        stopForeground(STOP_FOREGROUND_DETACH)
                        stopSelf()
                    }
                }
                override fun onError(utteranceId: String?) {
                    stopForeground(STOP_FOREGROUND_DETACH)
                    stopSelf()
                }
            })

            pendingSpeechText?.let {
                speakMessage(it)
                pendingSpeechText = null
            }
        }
    }

    private fun buildNotification(title: String, reminderId: String, contentText: String? = null): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_SCREEN", "checkin")
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action Done
        val doneIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_NOTIFICATION_DONE
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, reminderId)
        }
        val donePendingIntent = PendingIntent.getBroadcast(
            this,
            1,
            doneIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action Snooze 15 minutes
        val snoozeIntent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_NOTIFICATION_SNOOZE
            putExtra(AlarmScheduler.EXTRA_REMINDER_ID, reminderId)
            putExtra(AlarmScheduler.EXTRA_REMINDER_TITLE, title)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            this,
            2,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Xestlab Assistant: $title")
            .setContentText(contentText ?: "Speaking reminder...")
            .setStyle(NotificationCompat.BigTextStyle().bigText(contentText ?: "Tap to open check-in."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openPendingIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background, "Done", donePendingIntent)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "Snooze 15m", snoozePendingIntent)
            .addAction(android.R.drawable.ic_menu_agenda, "Open", openPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Scheduled Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Accountability voice check-ins and goal nudges"
                enableLights(true)
                lightColor = Color.parseColor("#0F5F5C")
                enableVibration(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

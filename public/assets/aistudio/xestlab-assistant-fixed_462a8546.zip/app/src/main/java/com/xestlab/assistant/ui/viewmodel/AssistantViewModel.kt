package com.xestlab.assistant.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xestlab.assistant.data.local.AppDatabase
import com.xestlab.assistant.data.model.*
import com.xestlab.assistant.data.repository.AssistantRepository
import com.xestlab.assistant.data.repository.WeeklySummaryData
import com.xestlab.assistant.service.AlarmScheduler
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val repository = AssistantRepository(db)

    val goals: StateFlow<Goal> = repository.goals
        .map { it ?: Goal() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Goal())

    val checklistItems: StateFlow<List<ChecklistItem>> = repository.checklistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders: StateFlow<List<ReminderSchedule>> = repository.reminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<UserSettings> = repository.settings
        .map { it ?: UserSettings() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    private val _currentDate = MutableStateFlow(getTodayDateString())
    val currentDate: StateFlow<String> = _currentDate.asStateFlow()

    val todayLogs: StateFlow<List<DailyLog>> = _currentDate
        .flatMapLatest { date -> repository.getLogsForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _weeklySummary = MutableStateFlow(
        WeeklySummaryData(0, 50, 0, 5, 0, 3, 0, 0)
    )
    val weeklySummary: StateFlow<WeeklySummaryData> = _weeklySummary.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        refreshWeeklySummary()
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun markItemDone(itemId: String, count: Int = 0) {
        viewModelScope.launch {
            repository.markItemDone(_currentDate.value, itemId, count)
            refreshWeeklySummary()
            _toastMessage.value = "Item marked done"
        }
    }

    fun markItemNotDone(itemId: String, reason: String) {
        viewModelScope.launch {
            repository.markItemNotDone(_currentDate.value, itemId, reason)
            refreshWeeklySummary()
            _toastMessage.value = "Item marked not done: $reason"
        }
    }

    fun updateCountValue(itemId: String, count: Int) {
        viewModelScope.launch {
            repository.markItemDone(_currentDate.value, itemId, count)
            refreshWeeklySummary()
        }
    }

    fun refreshWeeklySummary() {
        viewModelScope.launch {
            val cal = Calendar.getInstance()
            cal.firstDayOfWeek = Calendar.MONDAY
            cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            val weekStart = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
            cal.add(Calendar.DAY_OF_WEEK, 6)
            val weekEnd = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)

            _weeklySummary.value = repository.getWeeklySummary(weekStart, weekEnd)
        }
    }

    fun saveGoal(updatedGoal: Goal) {
        viewModelScope.launch {
            repository.saveGoals(updatedGoal)
            refreshWeeklySummary()
            _toastMessage.value = "Goals updated"
        }
    }

    fun saveUserSettings(updatedSettings: UserSettings) {
        viewModelScope.launch {
            repository.saveSettings(updatedSettings)
            _toastMessage.value = "Settings saved"
        }
    }

    fun toggleReminderActive(reminder: ReminderSchedule) {
        viewModelScope.launch {
            val updated = reminder.copy(isActive = !reminder.isActive)
            repository.saveReminder(updated)
            if (updated.isActive) {
                AlarmScheduler.scheduleReminder(getApplication(), updated)
                _toastMessage.value = "${updated.title} activated"
            } else {
                AlarmScheduler.cancelReminder(getApplication(), updated.id)
                _toastMessage.value = "${updated.title} deactivated"
            }
        }
    }

    fun toggleReminderVoice(reminder: ReminderSchedule) {
        viewModelScope.launch {
            val updated = reminder.copy(voiceEnabled = !reminder.voiceEnabled)
            repository.saveReminder(updated)
        }
    }

    fun updateReminderTime(reminder: ReminderSchedule, newTime: String) {
        viewModelScope.launch {
            val updated = reminder.copy(timeString = newTime)
            repository.saveReminder(updated)
            if (updated.isActive) {
                AlarmScheduler.scheduleReminder(getApplication(), updated)
            }
            _toastMessage.value = "Time set to $newTime"
        }
    }

    fun addCustomReminder(title: String, timeString: String, isRepeating: Boolean) {
        viewModelScope.launch {
            val id = UUID.randomUUID().toString().take(8)
            val reminder = ReminderSchedule(
                id = id,
                title = title,
                timeString = timeString,
                isRepeating = isRepeating,
                daysOfWeek = "ALL",
                voiceEnabled = true,
                isActive = true,
                isBuiltIn = false
            )
            repository.saveReminder(reminder)
            AlarmScheduler.scheduleReminder(getApplication(), reminder)
            _toastMessage.value = "Custom reminder added for $timeString"
        }
    }

    fun deleteCustomReminder(reminder: ReminderSchedule) {
        viewModelScope.launch {
            repository.deleteReminder(reminder)
            AlarmScheduler.cancelReminder(getApplication(), reminder.id)
            _toastMessage.value = "Reminder removed"
        }
    }

    fun testReminderInOneMinute() {
        AlarmScheduler.scheduleTestReminder(getApplication())
        _toastMessage.value = "Test alarm scheduled for 1 minute from now."
    }

    fun completeFirstRun() {
        viewModelScope.launch {
            val cur = settings.value
            repository.saveSettings(cur.copy(isFirstRunComplete = true))
            AlarmScheduler.scheduleAllActive(getApplication())
        }
    }

    fun getWeeklyReviewPlainText(): String {
        val summary = _weeklySummary.value
        val goal = goals.value
        val sMsg = getStatusWord(summary.messagesCount, summary.messagesTarget)
        val sConv = getStatusWord(summary.conversationsCount, summary.conversationsTarget)
        val sQuotes = getStatusWord(summary.quotesCount, summary.quotesTarget)

        return listOf(
            "WEEKLY SUMMARY: Xestlab Assistant",
            "Outreach messages: ${summary.messagesCount} / ${summary.messagesTarget} ($sMsg)",
            "Conversations: ${summary.conversationsCount} / ${summary.conversationsTarget} ($sConv)",
            "Quotes sent: ${summary.quotesCount} / ${summary.quotesTarget} ($sQuotes)",
            "Content posts published: ${summary.contentCount}",
            "Study blocks completed: ${summary.studyCount}",
            "Annual goal target: 10,000,000 naira"
        ).joinToString("\n")
    }

    private fun getStatusWord(done: Int, target: Int): String {
        return when {
            done > target -> "Ahead"
            done == target || done >= target * 0.9 -> "On track"
            else -> "Behind"
        }
    }

    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
}

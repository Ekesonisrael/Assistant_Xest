package com.xestlab.assistant.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = TealAccent,
    onPrimary = Color.White,
    primaryContainer = SurfaceSubtleLight,
    onPrimaryContainer = TextPrimaryLight,
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    background = BgLight,
    onBackground = TextPrimaryLight,
    outline = BorderLight,
    error = WarningRed
)

private val DarkColorScheme = darkColorScheme(
    primary = TealAccentDark,
    onPrimary = Color(0xFF0A1C1B),
    primaryContainer = SurfaceSubtleDark,
    onPrimaryContainer = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    background = BgDark,
    onBackground = TextPrimaryDark,
    outline = BorderDark,
    error = WarningRedDark
)

val Shapes8px = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(8.dp),
    extraLarge = RoundedCornerShape(8.dp)
)

@Composable
fun XestlabTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        shapes = Shapes8px,
        content = content
    )
}

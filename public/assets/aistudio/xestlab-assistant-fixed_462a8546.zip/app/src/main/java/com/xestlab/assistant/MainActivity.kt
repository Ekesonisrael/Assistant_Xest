package com.xestlab.assistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import com.xestlab.assistant.ui.screens.CheckInScreen
import com.xestlab.assistant.ui.screens.SettingsScreen
import com.xestlab.assistant.ui.screens.SetupScreen
import com.xestlab.assistant.ui.screens.WeekScreen
import com.xestlab.assistant.ui.theme.XestlabTheme
import com.xestlab.assistant.ui.viewmodel.AssistantViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()
    private var requestedTab by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedTab = intent?.getStringExtra("OPEN_SCREEN")

        setContent {
            XestlabTheme {
                AppRoot(viewModel = viewModel, requestedTab = requestedTab)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        requestedTab = intent.getStringExtra("OPEN_SCREEN")
    }
}

private enum class Tab(val label: String) {
    CHECKIN("Check-in"),
    WEEK("Week"),
    SETTINGS("Settings")
}

@Composable
private fun AppRoot(viewModel: AssistantViewModel, requestedTab: String?) {
    val context = LocalContext.current
    val storedSettings by viewModel.repository.settings.collectAsState(initial = null)
    val toast by viewModel.toastMessage.collectAsState()

    var tab by remember { mutableStateOf(Tab.CHECKIN) }
    var showSetup by remember { mutableStateOf(false) }

    LaunchedEffect(toast) {
        toast?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    LaunchedEffect(requestedTab) {
        if (requestedTab == "checkin") tab = Tab.CHECKIN
        if (requestedTab == "week") tab = Tab.WEEK
    }

    val settings = storedSettings
    if (settings == null) {
        // Database is still being created on the very first launch
        Box(modifier = Modifier.fillMaxSize())
        return
    }

    if (!settings.isFirstRunComplete || showSetup) {
        SetupScreen(viewModel = viewModel, onComplete = { showSetup = false })
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = {},
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (tab) {
                Tab.CHECKIN -> CheckInScreen(viewModel = viewModel)
                Tab.WEEK -> WeekScreen(viewModel = viewModel)
                Tab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToSetup = { showSetup = true }
                )
            }
        }
    }
}

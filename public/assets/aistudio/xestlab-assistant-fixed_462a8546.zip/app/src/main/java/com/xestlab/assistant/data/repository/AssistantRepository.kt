package com.xestlab.assistant.data.repository

import com.xestlab.assistant.data.local.AppDatabase
import com.xestlab.assistant.data.model.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class AssistantRepository(private val db: AppDatabase) {

    val goals: Flow<Goal?> = db.goalDao().getGoals()
    val checklistItems: Flow<List<ChecklistItem>> = db.checklistDao().getAllItems()
    val reminders: Flow<List<ReminderSchedule>> = db.reminderDao().getAllReminders()
    val settings: Flow<UserSettings?> = db.settingsDao().getSettings()

    fun getLogsForDate(date: String): Flow<List<DailyLog>> {
        return db.dailyLogDao().getLogsForDate(date)
    }

    suspend fun markItemDone(date: String, itemId: String, count: Int = 0) {
        db.dailyLogDao().deleteLogForItem(date, itemId)
        val log = DailyLog(
            date = date,
            itemId = itemId,
            isDone = true,
            countValue = count,
            reasonNotDone = null,
            timestamp = System.currentTimeMillis()
        )
        db.dailyLogDao().insertLog(log)
    }

    suspend fun markItemNotDone(date: String, itemId: String, reason: String) {
        db.dailyLogDao().deleteLogForItem(date, itemId)
        val log = DailyLog(
            date = date,
            itemId = itemId,
            isDone = false,
            countValue = 0,
            reasonNotDone = reason,
            timestamp = System.currentTimeMillis()
        )
        db.dailyLogDao().insertLog(log)
    }

    suspend fun saveGoals(goal: Goal) {
        db.goalDao().saveGoals(goal)
    }

    suspend fun saveSettings(settings: UserSettings) {
        db.settingsDao().saveSettings(settings)
    }

    suspend fun saveReminder(reminder: ReminderSchedule) {
        db.reminderDao().insertReminder(reminder)
    }

    suspend fun deleteReminder(reminder: ReminderSchedule) {
        db.reminderDao().deleteReminder(reminder)
    }

    suspend fun getWeeklySummary(weekStartDate: String, weekEndDate: String): WeeklySummaryData {
        val logs = db.dailyLogDao().getLogsBetweenDates(weekStartDate, weekEndDate)
        val goal = db.goalDao().getGoalsDirect() ?: Goal()

        var messagesDone = 0
        var followUpsDone = 0
        var contentDone = 0
        var studyDone = 0
        var leadSheetDone = 0

        logs.forEach { log ->
            if (log.isDone) {
                when (log.itemId) {
                    "messages10" -> messagesDone += if (log.countValue > 0) log.countValue else 10
                    "followups" -> followUpsDone += 1
                    "content" -> contentDone += 1
                    "study" -> studyDone += 1
                    "leadsheet" -> leadSheetDone += 1
                }
            }
        }

        return WeeklySummaryData(
            messagesCount = messagesDone,
            messagesTarget = goal.weeklyMessagesTarget,
            conversationsCount = followUpsDone, // proxy or logged conversations
            conversationsTarget = goal.weeklyConversationsTarget,
            quotesCount = (leadSheetDone / 2).coerceAtLeast(0),
            quotesTarget = goal.weeklyQuotesTarget,
            contentCount = contentDone,
            studyCount = studyDone
        )
    }

    // Export and Import JSON with compatibility with web goal tracker
    suspend fun exportJson(): String {
        val root = JSONObject()
        val goal = db.goalDao().getGoalsDirect() ?: Goal()
        val settings = db.settingsDao().getSettingsDirect() ?: UserSettings()
        val allLogs = db.dailyLogDao().getAllLogs()
        val allReminders = db.reminderDao().getAllRemindersDirect()

        // Settings & Targets
        val settingsObj = JSONObject().apply {
            put("yearGoal", goal.yearlyGoal)
            put("startDate", goal.startDate)
            put("userName", settings.userName)
            put("quietHoursStart", settings.quietHoursStart)
            put("quietHoursEnd", settings.quietHoursEnd)
            put("quietHoursEnabled", settings.quietHoursEnabled)
            put("voiceSpeed", settings.voiceSpeed.toDouble())

            val weeklyObj = JSONObject().apply {
                put("messages", goal.weeklyMessagesTarget)
                put("conversations", goal.weeklyConversationsTarget)
                put("quotes", goal.weeklyQuotesTarget)
            }
            put("weeklyTargets", weeklyObj)

            val quarterObj = JSONObject().apply {
                put("q1", goal.q1Target)
                put("q2", goal.q2Target)
                put("q3", goal.q3Target)
                put("q4", goal.q4Target)
            }
            put("quarterTargets", quarterObj)
        }
        root.put("settings", settingsObj)

        // Logs
        val logsArray = JSONArray()
        allLogs.forEach { log ->
            val lObj = JSONObject().apply {
                put("date", log.date)
                put("itemId", log.itemId)
                put("isDone", log.isDone)
                put("countValue", log.countValue)
                put("reasonNotDone", log.reasonNotDone ?: "")
                put("timestamp", log.timestamp)
            }
            logsArray.put(lObj)
        }
        root.put("logs", logsArray)

        // Reminders
        val remindersArray = JSONArray()
        allReminders.forEach { r ->
            val rObj = JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("timeString", r.timeString)
                put("isRepeating", r.isRepeating)
                put("daysOfWeek", r.daysOfWeek)
                put("voiceEnabled", r.voiceEnabled)
                put("isActive", r.isActive)
                put("isBuiltIn", r.isBuiltIn)
            }
            remindersArray.put(rObj)
        }
        root.put("reminders", remindersArray)

        return root.toString(2)
    }

    suspend fun importJson(jsonString: String): Boolean {
        try {
            val root = JSONObject(jsonString)

            // Parse settings / goals (supports both web tracker and native backup)
            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                val currentGoal = db.goalDao().getGoalsDirect() ?: Goal()
                val currentSettings = db.settingsDao().getSettingsDirect() ?: UserSettings()

                val newYearGoal = sObj.optLong("yearGoal", currentGoal.yearlyGoal)
                val newStartDate = sObj.optString("startDate", currentGoal.startDate)

                var wMsg = currentGoal.weeklyMessagesTarget
                var wConv = currentGoal.weeklyConversationsTarget
                var wQuotes = currentGoal.weeklyQuotesTarget

                if (sObj.has("weeklyTargets")) {
                    val wObj = sObj.getJSONObject("weeklyTargets")
                    wMsg = wObj.optInt("messages", wMsg)
                    wConv = wObj.optInt("conversations", wConv)
                    wQuotes = wObj.optInt("quotes", wQuotes)
                }

                var q1 = currentGoal.q1Target
                var q2 = currentGoal.q2Target
                var q3 = currentGoal.q3Target
                var q4 = currentGoal.q4Target

                if (sObj.has("quarterTargets")) {
                    val qObj = sObj.getJSONObject("quarterTargets")
                    q1 = qObj.optLong("q1", q1)
                    q2 = qObj.optLong("q2", q2)
                    q3 = qObj.optLong("q3", q3)
                    q4 = qObj.optLong("q4", q4)
                }

                db.goalDao().saveGoals(
                    currentGoal.copy(
                        yearlyGoal = newYearGoal,
                        startDate = newStartDate,
                        weeklyMessagesTarget = wMsg,
                        weeklyConversationsTarget = wConv,
                        weeklyQuotesTarget = wQuotes,
                        q1Target = q1,
                        q2Target = q2,
                        q3Target = q3,
                        q4Target = q4
                    )
                )

                val newName = sObj.optString("userName", currentSettings.userName)
                val qStart = sObj.optString("quietHoursStart", currentSettings.quietHoursStart)
                val qEnd = sObj.optString("quietHoursEnd", currentSettings.quietHoursEnd)
                val qEnabled = sObj.optBoolean("quietHoursEnabled", currentSettings.quietHoursEnabled)
                val vSpeed = sObj.optDouble("voiceSpeed", currentSettings.voiceSpeed.toDouble()).toFloat()

                db.settingsDao().saveSettings(
                    currentSettings.copy(
                        userName = newName,
                        quietHoursStart = qStart,
                        quietHoursEnd = qEnd,
                        quietHoursEnabled = qEnabled,
                        voiceSpeed = vSpeed
                    )
                )
            }

            // Parse native logs or web tracker days format
            if (root.has("logs")) {
                val arr = root.getJSONArray("logs")
                val importedLogs = mutableListOf<DailyLog>()
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    importedLogs.add(
                        DailyLog(
                            date = item.getString("date"),
                            itemId = item.getString("itemId"),
                            isDone = item.getBoolean("isDone"),
                            countValue = item.optInt("countValue", 0),
                            reasonNotDone = if (item.has("reasonNotDone") && !item.isNull("reasonNotDone")) item.getString("reasonNotDone") else null,
                            timestamp = item.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                if (importedLogs.isNotEmpty()) {
                    db.dailyLogDao().insertAll(importedLogs)
                }
            } else if (root.has("days")) {
                // Compatibility with web tracker format
                val daysObj = root.getJSONObject("days")
                val importedLogs = mutableListOf<DailyLog>()
                val keys = daysObj.keys()
                while (keys.hasNext()) {
                    val dateKey = keys.next()
                    val dayData = daysObj.getJSONObject(dateKey)
                    val msgs = dayData.optInt("messagesSent", 0)
                    if (msgs > 0) {
                        importedLogs.add(DailyLog(date = dateKey, itemId = "messages10", isDone = true, countValue = msgs))
                    }
                    if (dayData.has("checklist")) {
                        val cl = dayData.getJSONObject("checklist")
                        if (cl.optBoolean("followups", false)) importedLogs.add(DailyLog(date = dateKey, itemId = "followups", isDone = true))
                        if (cl.optBoolean("content", false)) importedLogs.add(DailyLog(date = dateKey, itemId = "content", isDone = true))
                        if (cl.optBoolean("study", false)) importedLogs.add(DailyLog(date = dateKey, itemId = "study", isDone = true))
                        if (cl.optBoolean("leadsheet", false)) importedLogs.add(DailyLog(date = dateKey, itemId = "leadsheet", isDone = true))
                    }
                }
                if (importedLogs.isNotEmpty()) {
                    db.dailyLogDao().insertAll(importedLogs)
                }
            }

            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }
}

data class WeeklySummaryData(
    val messagesCount: Int,
    val messagesTarget: Int,
    val conversationsCount: Int,
    val conversationsTarget: Int,
    val quotesCount: Int,
    val quotesTarget: Int,
    val contentCount: Int,
    val studyCount: Int
)

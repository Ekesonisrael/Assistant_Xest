# Xestlab Assistant (Android)

Xestlab Assistant is a native Android (Kotlin, Jetpack Compose, Room) personal reminder and check-in assistant that speaks aloud. Built for an Abuja web design and social media studio targeting ₦10,000,000 revenue.

All data is stored purely on device in a local Room database. The app contains no user accounts, no analytics, and does not request `android.permission.INTERNET`.

---

## Features

1. **Exact Alarms with Android AlarmManager**
   - Rescheduled automatically after device reboot (`BOOT_COMPLETED`) and app update (`MY_PACKAGE_REPLACED`).
   - Default schedule:
     - Morning briefing: 07:30
     - Midday nudge: 12:30
     - Evening check-in: 19:30
     - Sunday review: 18:00
   - Configurable quiet hours and voice toggles.

2. **Spoken Voice Reminders (Android TextToSpeech)**
   - Spoken reminders run via a reliable foreground service compatible with Android 12 through Android 15.
   - Deterministic speech synthesis built directly from your stored Room database records (no AI API calls or cloud dependencies).
   - If an evening checklist item is left unfinished, the app nudges again after 30 minutes (maximum 2 extra nudges per item per day).

3. **Check-In Screen with Voice Input**
   - Large Done and Not done buttons for each daily item.
   - Reason logging on Not done: Busy, Forgot, Avoided it, Other.
   - Built-in microphone recognition with Android `SpeechRecognizer` understanding "done", "not done", and spoken numbers.

4. **Weekly Scorecard**
   - Live totals for outreach messages, conversations, and quotes against weekly studio targets.
   - Real-time status badge: On track, Behind, Ahead.
   - One-tap "Copy weekly summary" button for Sunday reviews.

5. **Data Backup & Web Goal Tracker Interoperability**
   - Full JSON Export and Import functionality.
   - Compatible with the web goal tracker backup format for seamless data transition.

---

## Building the APK via GitHub Actions

This repository includes a continuous integration workflow located at `.github/workflows/build-apk.yml`. Every commit pushed to GitHub automatically compiles the debug APK.

### Steps to Download the APK:
1. Push this repository to GitHub.
2. In your GitHub repository, click on the **Actions** tab at the top.
3. Select the latest workflow run named **Build Android Debug APK**.
4. Scroll to the bottom of the summary page to the **Artifacts** section.
5. Click **xestlab-assistant-debug-apk** to download the ZIP file containing `app-debug.apk`.
6. Extract `app-debug.apk` and transfer it to your Android device.

---

## Local Development & Manual Build

If building locally using Android Studio or command-line Gradle:

### Prerequisites:
- JDK 17 or higher
- Android SDK 35 (Android 15)
- Android Gradle Plugin 8.7.3

### Build Command:
```bash
# On Linux / macOS:
gradle assembleDebug

# (Android Studio creates the Gradle wrapper automatically when you open the project.)
```
The compiled APK will be created at: `app/build/outputs/apk/debug/app-debug.apk`.

---

## Installation & First-Run Setup on Android

Because background alarm delivery and TextToSpeech playback require background execution permissions, complete the following setup on initial launch:

### 1. Permissions
- **Notifications**: Allow notification access when prompted (Android 13+).
- **Exact Alarms**: When directed to system settings, enable "Allow setting alarms and reminders" for Xestlab Assistant (Android 12+).
- **Audio / Microphone**: Allow microphone access to use voice commands on the Check-in screen.

### 2. Disable Battery Optimisation
Aggressive battery management will kill background alarm receivers.
1. Open **Settings** > **Apps** > **Xestlab Assistant**.
2. Tap **Battery**.
3. Select **Unrestricted** (or add to "Never Sleeping Apps").

### 3. OEM Background Autostart Settings

#### Xiaomi / Redmi / POCO (MIUI / HyperOS)
1. Open the **Security** app.
2. Go to **Manage Apps** > **Permissions** > **Autostart**.
3. Toggle on **Xestlab Assistant**.
4. In **Battery saver**, select **No restrictions**.

#### Tecno (HiOS)
1. Open **Phone Master**.
2. Go to **Auto-start management** (or **App Management**).
3. Enable **Xestlab Assistant**.
4. In **Power saving management**, whitelist Xestlab Assistant from background freezing.

#### Infinix (XOS)
1. Open **Phone Master** or **Settings**.
2. Go to **App Management** > **Auto-launch management**.
3. Switch **Xestlab Assistant** to enabled.
4. Set battery usage to unrestricted.

#### Samsung (One UI)
1. Open **Settings** > **Battery and device care** > **Battery**.
2. Tap **Background usage limits**.
3. Open **Never sleeping apps** and add **Xestlab Assistant**.

### 4. Verify with 1-Minute Test Alarm
Open the **Setup** screen in Xestlab Assistant and tap **Test reminder in 1 minute**. Lock your screen and place the phone down. Within 60 seconds, the device will display the foreground notification and speak the test briefing aloud.

---

## Architecture

- **UI**: 100% Jetpack Compose with Material 3 styling.
- **Database**: AndroidX Room with Kotlin Coroutines and StateFlow.
- **Audio Service**: `ReminderService` running as a specialized Foreground Service (`specialUse`) for guaranteed background speech delivery on Android 12 to 15.
- **Receivers**: `AlarmReceiver` handles exact alarm intents; `BootReceiver` restores scheduled alarms after device reboots.
- **Theme**: Deep teal `#0F5F5C`, warning `#B3261E`, clean 8px border radius, no gradients, no emojis.


---

## Offline behaviour

The app has no INTERNET permission and works fully offline: alarms, spoken reminders, check-ins and the weekly scorecard all run from the on-device database.

Two things depend on your phone, not the app:
- **Voice out:** the phone's text-to-speech engine needs an English voice installed. In Settings > Text-to-speech, make sure English voice data is downloaded.
- **Voice in:** the microphone button asks Android for offline recognition. Download the English offline speech pack (Google app > Settings > Voice > Offline speech recognition), or it may need a connection to understand you.

## Changes in this version

- Alarm scheduling now covers every reminder (morning, midday, evening, Sunday, custom, test) instead of one fixed 07:30 alarm.
- Evening nudges repeat only while items are unfinished, at most twice a day.
- Deactivating or deleting a reminder cancels its alarm.
- New tab navigation: Check-in, Week, Settings, plus first-run Setup.
- Added the missing launcher icon and fixed the CI build (no Gradle wrapper jar in the repo).
